﻿using System.ComponentModel.DataAnnotations;

namespace ImageDatabase.Models
{
    public class product
    {
        [Key]
        public int id {  get; set; }
        public String name { get; set; }
        public int price { get; set; }
        public String image { get; set; }


    }
}
