﻿using Microsoft.EntityFrameworkCore;

namespace ImageDatabase.Models
{
    public class mycontext:DbContext
    {
        public mycontext(DbContextOptions options):base(options) 
        {
        }
        public DbSet<product> products { get; set; }
    }
}
