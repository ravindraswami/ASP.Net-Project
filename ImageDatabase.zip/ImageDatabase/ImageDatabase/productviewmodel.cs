﻿using System.ComponentModel.DataAnnotations;
namespace ImageDatabase
{
    public class productviewmodel
    {
        [Key]
        public int id { get; set; }
        public String name { get; set; }
        public int price { get; set; }
        public IFormFile photo { get; set; }
    }
}
