﻿using ImageDatabase.Models;
using Microsoft.AspNetCore.Mvc;

namespace ImageDatabase.Controllers
{
    public class productController : Controller
    {
        mycontext my_context;
        IWebHostEnvironment hostingenvironment;
        public productController(mycontext my, IWebHostEnvironment hc)
        {
            my_context = my;
            hostingenvironment = hc;
        }
        public IActionResult Index()
        {
            return View(my_context.products.ToList());
        }
        public IActionResult addproduct()
        {
            return View();
        }
        [HttpPost]
        public IActionResult addproduct(productviewmodel product1)
        {
            String filename = "";
            if (product1.photo != null)
            {
                String uploadfolder = Path.Combine(hostingenvironment.WebRootPath, "images");
                filename = Guid.NewGuid().ToString() + "_" + product1.photo.FileName;
                String filepath=Path.Combine(uploadfolder, filename);
                product1.photo.CopyTo(new FileStream(filepath, FileMode.Create));
            }
            product p = new product
            {
                name = product1.name,
                price = product1.price,
                image = filename
            };
            my_context.products.Add(p);
            my_context.SaveChanges();
            ViewBag.success = "Record Added";
            return View();
        }
    }
}
