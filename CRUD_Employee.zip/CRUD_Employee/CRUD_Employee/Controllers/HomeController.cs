﻿using CRUD_Employee.data;
using CRUD_Employee.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Net;

namespace CRUD_Employee.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private EmployeeDB_01Context _employeeDB_01Context;
        public HomeController(ILogger<HomeController> logger, EmployeeDB_01Context employeeDB_01Context)
        {
            _logger = logger;
            _employeeDB_01Context = employeeDB_01Context;
        }

        public IActionResult Index()
        {
            EmpModel empModel = new EmpModel();
            empModel.EmpList = new List<Emp>();
            var data = _employeeDB_01Context.EmpDetails.ToList();
            foreach (var item in data)
            {
                empModel.EmpList.Add(new Emp
                {
                    Rowid = item.Rowid,
                    EmpId = (int)item.EmpId,
                    EmpName = item.EmpName,
                    Address = item.Address,
                    Contact = item.Contact,
                    Email = item.Email,
                    Dob = (DateTime)item.Dob,
                    DateOfJoining = (DateTime)item.DateOfJoining
                }); 
            }
            return View(empModel);
        }
        [HttpGet]
        public IActionResult Save()
        {
            Emp emp = new Emp();
            return View(emp);
        }
        [HttpPost]
        public IActionResult Save(Emp emp)
        {
            try
            {
                var empdata = new EmpDetail()
                {
                   EmpId = emp.EmpId,
                   EmpName = emp.EmpName,
                   Address = emp.Address,
                   Contact = emp.Contact,
                   Email = emp.Email,
                   Dob = emp.Dob,
                   DateOfJoining = emp.DateOfJoining
                };
                _employeeDB_01Context.EmpDetails.Add(empdata);
                _employeeDB_01Context.SaveChanges();
                TempData["SaveStatus"] = 1;
            }
            catch (Exception e)
            {
                TempData["SaveStatus"] = 0;
            }
            return RedirectToAction("Index", "Home");
        }
        [HttpGet]
        public IActionResult Update(int Id = 0)
        {
            Emp emp = new Emp();
            var data = _employeeDB_01Context.EmpDetails.Where(m => m.EmpId == Id).FirstOrDefault();
            if (data != null)
            {
                emp.EmpId = data.EmpId;
                emp.EmpName = data.EmpName;
                emp.Address = data.Address;
                emp.Contact = data.Contact;
                emp.Email = data.Email;
                emp.Dob = (DateTime)data.Dob;
                emp.DateOfJoining = (DateTime)data.DateOfJoining;
            }
            return View(emp);
        }
        [HttpPost]
        public IActionResult Update(Emp emp)
        {
            try
            {
                var data = _employeeDB_01Context.EmpDetails.Where(m => m.EmpId == emp.EmpId).FirstOrDefault();
                data.EmpName = emp.EmpName;
                data.Address = emp.Address;
                data.Contact = emp.Contact;
                data.Email = emp.Email;
                data.Dob = (DateTime)emp.Dob;
                data.DateOfJoining = (DateTime)emp.DateOfJoining;
                _employeeDB_01Context.SaveChanges();
                TempData["UpdateStatus"] = 1;
            }
            catch (Exception e)
            {
                TempData["UpdateStatus"] = 0;
            }
            return RedirectToAction("Index", "Home");
        }
        [HttpGet]
        public IActionResult Delete(int Id = 0)
        {
            try
            {
                var data = _employeeDB_01Context.EmpDetails.Where(m => m.EmpId == Id).FirstOrDefault();
                if (data != null)
                {
                    _employeeDB_01Context.EmpDetails.Remove(data);
                    _employeeDB_01Context.SaveChanges();
                }
                TempData["DeleteStatus"] = 1;
            }
            catch (Exception e)
            {
                TempData["DeleteStatus"] = 1;
            }
            return RedirectToAction("Index", "Home");
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}