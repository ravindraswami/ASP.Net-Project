﻿using System;
using System.Collections.Generic;

namespace CRUD_Employee.data
{
    public partial class EmployeeMaster
    {
        public int Id { get; set; }
        public string EmployeeName { get; set; } = null!;
        public string Department { get; set; } = null!;
    }
}
