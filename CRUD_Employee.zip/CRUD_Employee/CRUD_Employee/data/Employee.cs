﻿using System;
using System.Collections.Generic;

namespace CRUD_Employee.data
{
    public partial class Employee
    {
        public long Id { get; set; }
        public string? Name { get; set; }
        public string? Designation { get; set; }
        public string? Location { get; set; }
    }
}
