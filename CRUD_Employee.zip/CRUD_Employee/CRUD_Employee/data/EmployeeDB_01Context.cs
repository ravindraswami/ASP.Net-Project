﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace CRUD_Employee.data
{
    public partial class EmployeeDB_01Context : DbContext
    {
        public EmployeeDB_01Context()
        {
        }

        public EmployeeDB_01Context(DbContextOptions<EmployeeDB_01Context> options)
            : base(options)
        {
        }

        public virtual DbSet<EmpDetail> EmpDetails { get; set; } = null!;
        public virtual DbSet<Employee> Employees { get; set; } = null!;
        public virtual DbSet<EmployeeMaster> EmployeeMasters { get; set; } = null!;
        public virtual DbSet<StudentDetail> StudentDetails { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=localhost;Database=EmployeeDB_01;User ID=sa;Password=rein@24;encrypt=true;trustServerCertificate=true;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<EmpDetail>(entity =>
            {
                entity.HasKey(e => e.Rowid);

                entity.ToTable("Emp_Details");

                entity.Property(e => e.Rowid).HasColumnName("rowid");

                entity.Property(e => e.Address)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.Contact)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.DateOfJoining)
                    .HasColumnType("date")
                    .HasColumnName("DateOfJoining");

                entity.Property(e => e.Dob)
                    .HasColumnType("date")
                    .HasColumnName("Dob");

                entity.Property(e => e.Email)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EmpId).HasColumnName("EmpId");

                entity.Property(e => e.EmpName)
                    .HasMaxLength(500)
                    .IsUnicode(false)
                    .HasColumnName("EmpName");
            });

            modelBuilder.Entity<Employee>(entity =>
            {
                entity.ToTable("Employee");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Designation).HasMaxLength(200);

                entity.Property(e => e.Location).HasMaxLength(200);
            });

            modelBuilder.Entity<EmployeeMaster>(entity =>
            {
                entity.Property(e => e.Department)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.EmployeeName)
                    .HasMaxLength(200)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<StudentDetail>(entity =>
            {
                entity.ToTable("StudentDetail");

                entity.Property(e => e.Name)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.Subject)
                    .HasMaxLength(500)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
