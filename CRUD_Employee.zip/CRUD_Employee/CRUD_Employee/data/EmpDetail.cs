﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CRUD_Employee.data
{
    public partial class EmpDetail
    {
        public int Rowid { get; set; }
        public int? EmpId { get; set; }

        [Required] 
        public string? EmpName { get; set; }
        public string? Address { get; set; }

        [Range(1, 10)]
        [StringLength(12, MinimumLength = 10)]
        public string? Contact { get; set; }
        
        public string? Email { get; set; }
        public DateTime? Dob { get; set; }
        public DateTime? DateOfJoining { get; set; }
        //public int Emp_id { get; internal set; }
    }
}
