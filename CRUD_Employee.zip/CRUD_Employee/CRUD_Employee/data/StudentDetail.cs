﻿using System;
using System.Collections.Generic;

namespace CRUD_Employee.data
{
    public partial class StudentDetail
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? Subject { get; set; }
        public int? Standard { get; set; }
    }
}
