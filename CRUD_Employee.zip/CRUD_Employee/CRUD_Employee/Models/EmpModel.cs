﻿using System.ComponentModel.DataAnnotations;
using System;
using System.Linq;
using System.Web;
using System.Collections.Generic;


namespace CRUD_Employee.Models
{
    public class EmpModel
    {
        public List<Emp> EmpList { get; set; }
    }
    public class Emp
    {
        public int? EmpId { get; set; }

        [Required]
        [StringLength(60, MinimumLength = 2)]
        public string EmpName { get; set; }

        [Required]
        public string Address { get; set; }

        [Required (ErrorMessage = "Contact is Required")]
        [StringLength(12, MinimumLength = 10)]
        [DataType(DataType.PhoneNumber)]
        [MaxLength(12)]
        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessage = "Not a valid Phone number")]
        public string Contact { get; set; }

        [Required (ErrorMessage = "Email Id is Required")]
        [DataType(DataType.EmailAddress)]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; }

        [Required]
        public DateTime Dob { get; set; }

        [Required]
        public DateTime DateOfJoining { get; set; }

        [Required]
        public int Rowid { get; internal set; }
    }
}
